package cn.likable.videos.gcmexam;

public interface Config {

    static final String YOUR_SERVER_URL = "http://192.168.1.106:8080/GCMphp/register.php";
    static final String GOOGLE_SENDER_ID = "317676410988";
    static final String TAG = "GCM Android Example";
    static final String DISPLAY_MESSAGE_ACTION = "cn.likable.videos.gcmexam.DISPLAY_MESSAGE";
    static final String EXTRA_MESSAGE = "message";
}