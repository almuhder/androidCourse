package cn.likable.videos.gcmexam;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.google.android.gcm.GCMBaseIntentService;

public class GCMIntentService extends GCMBaseIntentService {

    private Controller aController = null;

    public GCMIntentService() {
        super(Config.GOOGLE_SENDER_ID);
    }

    private static void generateNotification(Context context, String message) {
        int icon = R.mipmap.ic_launcher;
        String title = context.getString(R.string.app_name);
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pIntent = PendingIntent.getActivity(context, (int) System.currentTimeMillis(), intent, 0);
        Notification n = new Notification.Builder(context)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(icon)
                .setContentIntent(pIntent)
                .setAutoCancel(true).build();
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(0, n);
    }

    @Override
    protected void onRegistered(Context context, String registrationId) {
        if (aController == null)
            aController = (Controller) getApplicationContext();
        aController.displayMessageOnScreen(context, "Your device registred with GCM");
        aController.register(context, MainActivity.name, MainActivity.email, registrationId);
    }

    @Override
    protected void onUnregistered(Context context, String registrationId) {
        if (aController == null)
            aController = (Controller) getApplicationContext();
        aController.displayMessageOnScreen(context, getString(R.string.gcm_unregistered));
        aController.unregister(context, registrationId);
    }

    @Override
    protected void onMessage(Context context, Intent intent) {
        if (aController == null)
            aController = (Controller) getApplicationContext();
        String message = intent.getExtras().getString("price");
        aController.displayMessageOnScreen(context, message);
        generateNotification(context, message);
    }

    @Override
    protected void onDeletedMessages(Context context, int total) {
        if (aController == null)
            aController = (Controller) getApplicationContext();
        String message = getString(R.string.gcm_deleted, total);
        aController.displayMessageOnScreen(context, message);
        generateNotification(context, message);
    }

    @Override
    public void onError(Context context, String errorId) {
        if (aController == null)
            aController = (Controller) getApplicationContext();
        aController.displayMessageOnScreen(context, getString(R.string.gcm_error, errorId));
    }

    @Override
    protected boolean onRecoverableError(Context context, String errorId) {
        if (aController == null)
            aController = (Controller) getApplicationContext();
        aController.displayMessageOnScreen(context, getString(R.string.gcm_recoverable_error, errorId));
        return super.onRecoverableError(context, errorId);
    }

}