package cn.likable.videos.gcmexam;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gcm.GCMRegistrar;

public class MainActivity extends AppCompatActivity {

    public static String name;
    public static String email;
    TextView lblMessage;
    Controller aController;
    private final BroadcastReceiver mHandleMessageReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String newMessage = intent.getExtras().getString(Config.EXTRA_MESSAGE);
            aController.acquireWakeLock(getApplicationContext());
            lblMessage.append(newMessage + "");
            Toast.makeText(getApplicationContext(),
                    "Got Message: " + newMessage,
                    Toast.LENGTH_LONG).show();
            aController.releaseWakeLock();
        }
    };
    AsyncTask<Void, Void, Void> mRegisterTask;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        aController = (Controller) getApplicationContext();
        if (!aController.isConnectingToInternet()) {
            aController.showAlertDialog(MainActivity.this, "Internet Connection Error",
                    "Please connect to Internet connection", false);
            return;
        }
        Intent i = getIntent();
        name = i.getStringExtra("name");
        email = i.getStringExtra("email");
        GCMRegistrar.checkDevice(this);
        GCMRegistrar.checkManifest(this);
        lblMessage = (TextView) findViewById(R.id.lblMessage);
        registerReceiver(mHandleMessageReceiver, new IntentFilter(Config.DISPLAY_MESSAGE_ACTION));
        final String regId = GCMRegistrar.getRegistrationId(this);
        if (regId.equals("")) {
            GCMRegistrar.register(this, Config.GOOGLE_SENDER_ID);
        } else {
            if (GCMRegistrar.isRegisteredOnServer(this)) {
                Toast.makeText(getApplicationContext(),
                        "Already registered with GCM Server",
                        Toast.LENGTH_LONG).
                        show();
            } else {
                final Context context = this;
                mRegisterTask = new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... params) {
                        aController.register(context, name, email, regId);
                        return null;
                    }

                    @Override
                    protected void onPostExecute(Void result) {
                        mRegisterTask = null;
                    }

                };
                mRegisterTask.execute(null, null, null);
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (mRegisterTask != null) {
            mRegisterTask.cancel(true);
        }
        try {
            unregisterReceiver(mHandleMessageReceiver);
            GCMRegistrar.onDestroy(this);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
