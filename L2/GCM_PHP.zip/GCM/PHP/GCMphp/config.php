<?php

define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "gcmexam");
define("GOOGLE_API_KEY", "AIzaSyD7x7bcps0ySuDxwnYWBS3BfSfvA0ZO-iY");
