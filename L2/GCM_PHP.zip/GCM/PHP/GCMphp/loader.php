<?php

require_once('config.php');
require_once('functions.php');
$conn = @mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
if (!@mysql_select_db(DB_DATABASE)) {
    print "Not connected with database.";
}
