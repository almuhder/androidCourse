﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    
    public DataTable readData()
    {
        try
        {
            //this is the bridge to database
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["usersDB"].ConnectionString);
            string strSQL = "select registerID from devices ";
            conn.Open();

            SqlCommand cmd = new SqlCommand(strSQL, conn);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            conn.Close();
            return dt;

           
           // return strPhone;
        }
        catch (Exception ex)
        {
            DataTable dt11 = new DataTable();
            return dt11;
        
        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataTable dt = readData();
       // String RegisterationID;
        foreach (DataRow row in dt.Rows)
        {
            string regID = row["registerID"].ToString();

            WebRequest tRequest;
            tRequest = WebRequest.Create("https://android.googleapis.com/gcm/send");
            tRequest.Method = "post";
            tRequest.ContentType = "application/x-www-form-urlencoded";
            tRequest.Headers.Add(string.Format("Authorization: key={0}", "AIzaSyB3k6Wzb3mB3IHQnYdgF1a10KZrZgCzl_c"));

            String collaspeKey = Guid.NewGuid().ToString("n");

            String postData = "registration_id=" + regID + "&data1=" + TextBox1.Text + "&collapse_key=" + collaspeKey;
            Byte[] byteArray = Encoding.UTF8.GetBytes(postData);
            tRequest.ContentLength = byteArray.Length;

            Stream dataStream = tRequest.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();

            WebResponse tResponse = tRequest.GetResponse();

            dataStream = tResponse.GetResponseStream();

            StreamReader tReader = new StreamReader(dataStream);

            String sResponseFromServer = tReader.ReadToEnd();

            tReader.Close();
            dataStream.Close();
            tResponse.Close();

        }
     //   RegisterationID = "APA91bFd3rQN8Sn85xLkOUzuVVQubztXVzHFL_335yQ8N8LJM9_O8d4UCJaC1OLOyuZbgEjBCe0BDDvFM1qPTvvzceLPgxWzT766jmzUza0kPja-3Ub-n-Gcgt_Yv9KRe_flyJp899Wm5ia7Q6ChKfTXptVrcGWhNA";

     //   WebRequest tRequest;
     //   tRequest = WebRequest.Create("https://android.googleapis.com/gcm/send");
     //   tRequest.Method = "post";
     //   tRequest.ContentType = "application/x-www-form-urlencoded";
     //   tRequest.Headers.Add(string.Format("Authorization: key={0}", "AIzaSyB3k6Wzb3mB3IHQnYdgF1a10KZrZgCzl_c"));

     //   String collaspeKey = Guid.NewGuid().ToString("n");

    //    String postData = "registration_id=" + RegisterationID + "&data1=" + TextBox1.Text + "&collapse_key=" + collaspeKey;
    //    Byte[] byteArray = Encoding.UTF8.GetBytes(postData);
    //    tRequest.ContentLength = byteArray.Length;

   //     Stream dataStream = tRequest.GetRequestStream();
   //     dataStream.Write(byteArray, 0, byteArray.Length);
   //     dataStream.Close();

   //     WebResponse tResponse = tRequest.GetResponse();

   //     dataStream = tResponse.GetResponseStream();

   //     StreamReader tReader = new StreamReader(dataStream);

   //     String sResponseFromServer = tReader.ReadToEnd();

   //     tReader.Close();
   //     dataStream.Close();
   //     tResponse.Close();

    }
}