﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Services;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class WebService : System.Web.Services.WebService {
    JavaScriptSerializer serializer;
    public WebService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }





       
public void getContactsJSONContext(string id)
{
	HttpContext context = this.Context;
	string strJson = "";

	Contact[] c = new Contact[3];
	
    c[0] = new Contact();
	c[0].CID = 1;
	c[0].CName = "Mohannad";

	c[1] = new Contact();
	c[1].CID = 1;
	c[1].CName = "Mohannad1";

	
	//c(2) = New Contact
	//c(2).CID = 2
	//c(2).CName = "Mohannad2"



	strJson = "{" + "\"" + "contacts" + "\":" + serializer.Serialize(c) + "}";
	context.Response.Write(strJson);
}

    



    [WebMethod()]    
    public void saveData(String RegisterID)
    {
        try
        {
            String strJson = "";
            HttpContext context = this.Context;
            //this is the bridge to database
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["usersDB"].ConnectionString);
            
            string strSQL = "insert into devices(registerID) values(@RegisterID)";
            conn.Open();

            SqlCommand cmd = new SqlCommand(strSQL, conn);
            cmd.Parameters.AddWithValue("@RegisterID", RegisterID);
            
            cmd.ExecuteNonQuery();
            conn.Close();

            strJson = "{\"" +serializer.Serialize( "1")+ "\"}";
          //  strJson = "{" + "\"" + "result" + "\":[" + "{\""+ "1" + "\"}"+"]}";
           // strJson = "{" + "\"" + "result" + "\":" + "\"" + "1" + "\"" + "}";
        context.Response.Write(strJson);
        }
        catch (Exception ex)
        {
            String strJson;
            HttpContext context = this.Context;
            strJson = "{" + "\"" + "result" + "\":" + "\"" + serializer.Serialize( "0") + "\"" + "}";
            context.Response.Write(strJson);
        }


    }


}
