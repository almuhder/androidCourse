package com.mgm.abcdefg;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;


public class MyBroadcastReceiver extends BroadcastReceiver 
{
	public void onReceive(Context context, Intent intent) 
	{
		try
		{
			String action = intent.getAction();
			if (action.equals("com.google.android.c2dm.intent.REGISTRATION"))
				{ 
				String registrationId = intent.getStringExtra("registration_id");
					String error = intent.getStringExtra("error");
					String unregistered = intent.getStringExtra("unregistered");
					Intent i =new Intent(context,ActivityReceiveMessage.class);
			    	i.putExtra("data", registrationId);
			    	i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			    	context.startActivity(i);				
					RequestQueue queue = Volley.newRequestQueue(context);
					Map<String, String> params = new HashMap<String, String>();
			        params.put("RegisterID",registrationId);
			        CustomRequest jsObjRequest = new CustomRequest(Method.PUBLIC,
			        	      "http://192.168.3.104/WebService.asmx/saveData",params,
			        	      new Response.Listener<JSONObject>()
			        	        {
			        		            public void onResponse(JSONObject response) 
			        		            {
			        		               System.out.println(response);
			        		               
			        						try
			        						   {

			        								String result=response.getString("result");
			        						    } 
			        				         catch (JSONException e) 
			        				            {					
			        				              	      e.printStackTrace();
			        						    }
			        				   			
			        				     }
			        			   },
			        			       new Response.ErrorListener() 
			        			       {
			        			           @Override
			        			           public void onErrorResponse(VolleyError error) 
			        			           {
			        			        	
			        			        	   String x= "";
			        			        	   
			        			        	 x="sdsd";
			        			           }
			        			       }
			        	     
			        			
			        			
			        			
			        			
			        			
			        			
			        			);

			        queue.add(jsObjRequest);
			        			
				}
			else if (action.equals("com.google.android.c2dm.intent.RECEIVE"))
				{ 
				//String data1 = intent.getStringExtra("abc");
				String data1; 
				data1= intent.getExtras().getString("data1");
		    	Intent i =new Intent(context,ActivityReceiveMessage.class);
		    	i.putExtra("data", data1);
		    	i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		    	context.startActivity(i);				
				//Bundle x=intent.getExtras();
//				String w=x.toString(); 
//				String data2 = intent.getStringExtra("data2");
//				
//				NotificationManager n=(NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
//				Notification mBuilder =	 new Notification();
//				mBuilder.setLatestEventInfo(context, "dfdf", "dfdfdf",new Intent(context,A2.class));
//				
//				n.notify( 0,mBuilder);
				}
		}
		finally { }
	}
}