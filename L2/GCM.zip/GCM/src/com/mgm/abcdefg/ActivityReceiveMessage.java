package com.mgm.abcdefg;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.gcm.R;

public class ActivityReceiveMessage extends Activity {

	TextView tv1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_activity_receive_message);
		tv1=(TextView) findViewById(R.id.textView1);
		Intent i=getIntent();
		tv1.setText(i.getExtras().getString("data"));
	}
}
