package com.example.admin.listviewwithimage;

/**
 * Created by admin on 3/22/16.
 */
public class Contact {

    String name;
    String phone;
    int photo;

    // constructor
    public Contact(String name, String phone, int photo){
        this.name = name;
        this.phone = phone;
        this.photo = photo;
    }
}
